package chatapp.part1;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    private Login login;

    @Before
    public void setUp() {
        login = Login.getInstance();
    }

    // Username tests
    @Test
    public void testValidUserName() {
        assertTrue(login.checkUserName("ab_c"));
    }

    @Test
    public void testInvalidUserName_NoUnderscore() {
        assertFalse(login.checkUserName("abcd"));
    }

    @Test
    public void testInvalidUserName_TooLong() {
        assertFalse(login.checkUserName("abc_de"));
    }

    @Test
    public void testInvalidUserName_NullOrEmpty() {
        assertFalse(login.checkUserName(null));
        assertFalse(login.checkUserName(""));
    }

    // Password tests
    @Test
    public void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Happy4boy!"));
    }

    @Test
    public void testInvalidPassword_NoUppercase() {
        assertFalse(login.checkPasswordComplexity("happyboy4!"));
    }

    @Test
    public void testInvalidPassword_NoDigit() {
        assertFalse(login.checkPasswordComplexity("Happyboy!"));
    }

    @Test
    public void testInvalidPassword_NoSpecialChar() {
        assertFalse(login.checkPasswordComplexity("Happyboy4"));
    }

    @Test
    public void testInvalidPassword_TooShort() {
        assertFalse(login.checkPasswordComplexity("hb4!"));
    }

    // Phone tests
    @Test
    public void testValidCellPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testInvalidCellPhoneNumber_NoCode() {
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testInvalidCellPhoneNumber_WrongLength() {
        assertFalse(login.checkCellPhoneNumber("+27831234"));
        assertFalse(login.checkCellPhoneNumber("+2783123456789"));
    }

    @Test
    public void testInvalidCellPhoneNumber_Null() {
        assertFalse(login.checkCellPhoneNumber(null));
    }

    // Registration tests
    @Test
    public void testSuccessfulRegistration() {
        String result = login.registerUser("Kyle", "Dawn", "ky_d", "Happyboy4!", "+27831234567");
        assertTrue(result.contains("Username successfully captured"));
        assertTrue(result.contains("Password successfully captured"));
        assertTrue(result.contains("Cell phone number successfully added"));
    }

    @Test
    public void testRegistrationFails_InvalidUsername() {
        String result = login.registerUser("Kyle", "Dawn", "kyled", "Happyboy4!", "+27831234567");
        assertTrue(result.contains("Username is not correctly formatted"));
    }

    @Test
    public void testRegistrationFails_InvalidPassword() {
        String result = login.registerUser("Kyle", "Dawn", "ky_d", "happyboy", "+27831234567");
        assertTrue(result.contains("Password is not correctly formatted"));
    }

    @Test
    public void testRegistrationFails_InvalidPhone() {
        String result = login.registerUser("Kyle", "Dawn", "ky_d", "Happyboy4!", "0831234567");
        assertTrue(result.contains("Cell number is incorrectly formatted"));
    }

    // Login tests
    @Test
    public void testSuccessfulLogin() {
        login.registerUser("James", "Smith", "js_m", "Secure1!", "+27831234567");
        assertTrue(login.loginUser("js_m", "Secure1!"));
    }

    @Test
    public void testFailedLogin_WrongPassword() {
        login.registerUser("James", "Smith", "js_m", "Secure1!", "+27831234567");
        assertFalse(login.loginUser("js_m", "WrongPass1!"));
    }

    @Test
    public void testFailedLogin_NoUserRegistered() {
        Login freshLogin = new Login(); // normally not possible, but added here for test clarity
        assertFalse(freshLogin.loginUser("user", "pass"));
    }

    // Login status test
    @Test
    public void testReturnLoginStatus() {
        login.registerUser("Alice", "Brown", "a_b", "Strong1!", "+27831234567");
        String status = login.returnLoginStatus();
        assertTrue(status.contains("Welcome Alice Brown"));
    }
}
//This is the Refrence
//OpenAI. 2025. ChatGPT.