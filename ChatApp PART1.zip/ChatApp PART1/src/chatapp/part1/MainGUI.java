/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part1;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainGUI extends JFrame {
    private JPanel mainPanel;
    private LoginPanel loginPanel;
    private Register registerPanel;
    private Timer slideTimer;
    private int slidePosition = 0;
    private boolean isShowingLogin = true;
    
    private static final int WINDOW_WIDTH = 450;
    private static final int WINDOW_HEIGHT = 600;

    public MainGUI() {
        initializeWindow();
        initializePanels();
        setupSlideAnimation();
        setVisible(true);
    }

    private void initializeWindow() {
        setTitle("Login and Registration System");
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Main panel with black/purple background
        mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(15, 0, 20));
        add(mainPanel);
    }

    private void initializePanels() {
        // Created login and register panels
        loginPanel = new LoginPanel(this);
        registerPanel = new Register(this);
        
        // sliding effect
        loginPanel.setBounds(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        registerPanel.setBounds(WINDOW_WIDTH, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        
        mainPanel.add(loginPanel);
        mainPanel.add(registerPanel);
    }

    private void setupSlideAnimation() {
        slideTimer = new Timer(8, e -> performSlideAnimation());
    }

    public void showRegisterPanel() {
        if (!slideTimer.isRunning() && isShowingLogin) {
            isShowingLogin = false;
            slideTimer.start();
        }
    }

    public void showLoginPanel() {
        if (!slideTimer.isRunning() && !isShowingLogin) {
            isShowingLogin = true;
            slideTimer.start();
        }
    }

    private void performSlideAnimation() {
        int slideSpeed = 12;
        
        if (!isShowingLogin) { // Sliding to register
            slidePosition += slideSpeed;
            if (slidePosition >= WINDOW_WIDTH) {
                slidePosition = WINDOW_WIDTH;
                slideTimer.stop();
            }
        } else { // Sliding to login
            slidePosition -= slideSpeed;
            if (slidePosition <= 0) {
                slidePosition = 0;
                slideTimer.stop();
            }
        }
        
        // Update panel positions
        loginPanel.setLocation(-slidePosition, 0);
        registerPanel.setLocation(WINDOW_WIDTH - slidePosition, 0);
        mainPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                new MainGUI();
            }
        });
    }
}

// OpenAI. 2025. ChatGPT.
