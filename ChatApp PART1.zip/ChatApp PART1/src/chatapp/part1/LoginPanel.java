/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part1;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginPanel extends JPanel {
    private MainGUI mainGUI;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginBtn;
    private JButton registerBtn;
    private JLabel statusLabel;

    public LoginPanel(MainGUI mainGUI) {
        this.mainGUI = mainGUI;
        initializeComponents();
        setupEventHandlers();
    }

    private void initializeComponents() {
        setLayout(null);
        setBackground(new Color(30, 0, 60)); // Purple background

        // Header
        JLabel headerLabel = new JLabel("Login");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 38));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setBounds(160, 50, 120, 60);
        add(headerLabel);

        // Username
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.LIGHT_GRAY);
        usernameLabel.setBounds(100, 160, 100, 20);
        add(usernameLabel);
        
        usernameField = new JTextField();
        styleTextField(usernameField);
        usernameField.setBounds(100, 200, 200, 35);
        add(usernameField);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.LIGHT_GRAY);
        passwordLabel.setBounds(100, 250, 100, 20);
        add(passwordLabel);
        
        passwordField = new JPasswordField();
        styleTextField(passwordField);
        passwordField.setBounds(100, 290, 200, 35);
        add(passwordField);

        // Login Button
        loginBtn = new JButton("Login");
        styleButton(loginBtn);
        loginBtn.setBounds(150, 350, 100, 40);
        add(loginBtn);

        // Register Button
        registerBtn = new JButton("Create Account");
        styleButton(registerBtn);
        registerBtn.setBounds(130, 420, 140, 35);
        add(registerBtn);

        // Status Label
        statusLabel = new JLabel("");
        statusLabel.setForeground(Color.PINK);
        statusLabel.setBounds(50, 380, 300, 60);
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(statusLabel);
    }

    private void styleTextField(JTextField field) {
        field.setBackground(new Color(200, 200, 200)); // Light grey
        field.setForeground(Color.BLACK);
        field.setBorder(BorderFactory.createLineBorder(new Color(100, 0, 150), 2));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 20));
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(128, 0, 128));
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
    }

    private void setupEventHandlers() {
        loginBtn.addActionListener(e -> handleLogin());
        registerBtn.addActionListener(e -> mainGUI.showRegisterPanel());
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        Login login = Login.getInstance();
        
        if (login.loginUser(username, password)) {
            String welcomeMessage = login.returnLoginStatus();
            statusLabel.setForeground(new Color(0, 255, 100)); // Green for success
            statusLabel.setText("<html><div style='text-align: center;'>" + welcomeMessage + "</div></html>");
        } else {
            statusLabel.setForeground(Color.PINK); // Pink for error
            statusLabel.setText("Username or password incorrect, please try again.");
        }
    }
}
